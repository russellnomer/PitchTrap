"""
PitchTrap – Multi-provider, BYOK monetized MVP
"""

from __future__ import annotations

import logging
from flask import Flask, request, Response, render_template, redirect, url_for, session, flash

from config import SECRET_KEY, DEBUG, PORT
from triage import classify_offer
from bot_logic import next_response, clear_state, is_finished
from providers import get_provider

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pitchtrap")

app = Flask(__name__)
app.secret_key = SECRET_KEY


# ---------------------------------------------------------------------------
# Public pages
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/onboarding")
def onboarding():
    """Guided flow for users to connect their own Twilio or SignalWire keys."""
    return render_template("onboarding.html")


@app.route("/onboarding/connect", methods=["POST"])
def onboarding_connect():
    """
    Receive provider choice + credentials from the user.
    In production this would:
      1. Validate the keys
      2. Encrypt and store them against the user account
      3. Mark the account as activated
    """
    provider = request.form.get("provider", "").lower()
    if provider not in ("twilio", "signalwire"):
        flash("Please choose a valid provider", "error")
        return redirect(url_for("onboarding"))

    # Collect credentials
    creds = {}
    if provider == "twilio":
        creds = {
            "account_sid": request.form.get("account_sid", "").strip(),
            "auth_token": request.form.get("auth_token", "").strip(),
        }
    else:
        creds = {
            "project_id": request.form.get("project_id", "").strip(),
            "api_token": request.form.get("api_token", "").strip(),
            "space_url": request.form.get("space_url", "").strip(),
        }

    try:
        adapter = get_provider(provider, creds)
        ok, message = adapter.validate_credentials()
        if not ok:
            flash(f"Validation failed: {message}", "error")
            return redirect(url_for("onboarding"))

        # In a real system we would encrypt + persist here.
        # For the MVP we just confirm success.
        session["provider"] = provider
        session["provider_ok"] = True
        flash(f"Successfully connected {provider.title()}: {message}", "success")
        return redirect(url_for("dashboard"))
    except Exception as e:
        flash(f"Error: {str(e)[:150]}", "error")
        return redirect(url_for("onboarding"))


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", provider=session.get("provider"))


# ---------------------------------------------------------------------------
# Telephony / SMS webhooks (multi-tenant ready)
# ---------------------------------------------------------------------------

@app.route("/voice/incoming", methods=["POST"])
def voice_incoming():
    """
    Generic voice webhook. In production the URL would be unique per user
    or contain a tenant identifier so we can load the correct provider keys.
    """
    call_sid = request.values.get("CallSid", "unknown")
    speech = request.values.get("SpeechResult", "").strip()

    # For the MVP we assume a system-level or session provider.
    # Real multi-tenant version loads encrypted keys by tenant ID.
    provider_name = session.get("provider", "twilio")
    # Placeholder credentials – real system loads from encrypted store
    creds = {}  # would be loaded from DB
    try:
        adapter = get_provider(provider_name, creds)
    except Exception:
        # Fallback simple TwiML so the call doesn't completely fail
        from twilio.twiml.voice_response import VoiceResponse
        resp = VoiceResponse()
        resp.say("PitchTrap is not fully configured for this number yet.")
        resp.hangup()
        return Response(str(resp), mimetype="application/xml")

    if not speech:
        # First leg of the call
        twiml = adapter.build_voice_response(
            "Thank you for calling. Please briefly describe the funding offer you are presenting.",
            gather=True,
            action_url="/voice/incoming",
        )
        return Response(twiml, mimetype="application/xml")

    # Triage
    result = classify_offer(speech)
    logger.info("Voice triage %s → %s", call_sid, result.category)

    if result.category == "Ugly":
        twiml = adapter.build_voice_response(
            "We are not interested in this type of offer. Please remove this number from your list. Goodbye."
        )
        clear_state(call_sid)
        return Response(twiml, mimetype="application/xml")

    if result.category == "Good":
        twiml = adapter.build_voice_response(
            "This appears complete enough for human review. Please email the full written offer. Goodbye."
        )
        clear_state(call_sid)
        return Response(twiml, mimetype="application/xml")

    # Bad → engage
    bot_text = next_response(call_sid, speech)
    finished = is_finished(call_sid)

    twiml = adapter.build_voice_response(
        bot_text,
        gather=not finished,
        action_url="/voice/incoming" if not finished else None,
    )
    if finished:
        clear_state(call_sid)
    return Response(twiml, mimetype="application/xml")


@app.route("/sms/incoming", methods=["POST"])
def sms_incoming():
    """Incoming SMS webhook – same triage + engagement logic."""
    body = request.values.get("Body", "").strip()
    from_number = request.values.get("From", "")
    to_number = request.values.get("To", "")

    result = classify_offer(body)
    logger.info("SMS triage from %s → %s", from_number, result.category)

    # For MVP we just log. Real version would reply via the user's provider.
    if result.category == "Ugly":
        reply = "Not interested. Please remove this number from your list."
    elif result.category == "Good":
        reply = "Thank you. Please email the complete written offer for review."
    else:
        # Start Level 2 over SMS
        reply = next_response(f"sms-{from_number}", body)

    # In production: load user's provider and call adapter.send_sms(...)
    return Response(
        f'<?xml version="1.0" encoding="UTF-8"?><Response><Message>{reply}</Message></Response>',
        mimetype="application/xml",
    )


# ---------------------------------------------------------------------------
# Local runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT, debug=DEBUG)
